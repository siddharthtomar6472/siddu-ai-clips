# Siddu AI Clips

A deployable starter app for AI-assisted short-form video clipping.

## What works
- Responsive creator dashboard
- Upload MP4/MOV/MKV/WebM
- Speech transcription with Faster-Whisper
- Heuristic transcript-based moment selection
- Vertical 9:16 center crop
- Burned-in subtitles
- MP4 downloads

## Important limitations
- The YouTube tab validates a URL but does not download or process YouTube media. Use the upload flow for videos you own or have permission to edit. An authorized YouTube integration requires OAuth/API work and must respect YouTube terms and copyright.
- Highlight selection is a basic heuristic, not Vizard-level proprietary AI. Replace `pick_clips()` with a trained ranker or an LLM scoring service for better results.
- Free hosting plans may sleep, limit CPU/RAM, request size and processing time. Whisper model download and video processing can exceed free-tier limits. For production, use a persistent worker/queue and object storage.
- This is a starter project, not yet a public live website. You must deploy it to a hosting account.

## Run locally
1. Install Python 3.11+ and FFmpeg (including ffprobe and libass).
2. `pip install -r requirements.txt`
3. `uvicorn app:app --reload`
4. Open http://localhost:8000

## Deploy
- Create a GitHub repository and upload these project files.
- Create a web service on Render and connect the repository (Docker runtime).
- Wait for build and open the service URL.
- For longer videos, use a paid worker/compute instance or a separate background job system.
