import os, uuid, shutil, subprocess, re
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles

ROOT = Path(__file__).parent
UPLOADS = ROOT / "uploads"
OUTPUTS = ROOT / "outputs"
UPLOADS.mkdir(exist_ok=True)
OUTPUTS.mkdir(exist_ok=True)

app = FastAPI(title="Siddu AI Clips")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
app.mount("/outputs", StaticFiles(directory=OUTPUTS), name="outputs")

@app.get("/", response_class=HTMLResponse)
def home():
    return (ROOT / "static" / "index.html").read_text(encoding="utf-8")

def run(cmd):
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode:
        raise RuntimeError(p.stderr[-1800:])

def transcribe(path):
    # Lazy import keeps the app start-up quick. Model downloads on first use.
    from faster_whisper import WhisperModel
    model_name = os.getenv("WHISPER_MODEL", "base")
    model = WhisperModel(model_name, device="cpu", compute_type="int8")
    segments, info = model.transcribe(str(path), vad_filter=True)
    return [{"start": float(s.start), "end": float(s.end), "text": s.text.strip()} for s in segments if s.text.strip()]

def pick_clips(segments, duration, count=5, clip_len=35):
    # Lightweight transcript heuristics; replace with an LLM ranker for production.
    cues = ["लेकिन", "क्योंकि", "कैसे", "क्यों", "सबसे", "गलती", "secret", "secret", "लेकिन", "सोचिए",
            "imagine", "amazing", "important", "problem", "solution", "mistake", "never", "always",
            "कभी", "पहली", "याद", "सच", "मतलब", "सीख"]
    scored = []
    for i, s in enumerate(segments):
        text = s["text"].lower()
        score = min(len(text), 180) / 30
        score += sum(1.5 for cue in cues if cue.lower() in text)
        score += 0.7 if "?" in text else 0
        center = (s["start"] + s["end"]) / 2
        start = max(0, center - clip_len / 2)
        end = min(duration, start + clip_len)
        if end - start >= 12:
            scored.append((score, start, end))
    scored.sort(reverse=True)
    chosen = []
    for score, start, end in scored:
        if all(abs(start - old[0]) > clip_len * 0.8 for old in chosen):
            chosen.append((start, end, score))
        if len(chosen) >= count:
            break
    if not chosen:
        for start in range(0, int(duration), clip_len):
            end = min(duration, start + clip_len)
            if end - start >= 12:
                chosen.append((start, end, 0))
            if len(chosen) >= count: break
    return chosen

def make_ass(segments, start, end, out):
    # Basic readable centered subtitles, timed from Whisper transcript.
    def stamp(sec):
        h = int(sec // 3600); m = int((sec % 3600) // 60); s = sec % 60
        return f"{h}:{m:02d}:{s:05.2f}".replace(".", ".")
    lines = [
        "[Script Info]", "ScriptType: v4.00+", "PlayResX: 1080", "PlayResY: 1920", "",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
        "Style: Default,Arial,64,&H00FFFFFF,&H000000FF,&H00000000,&H90000000,-1,0,0,0,100,100,0,0,1,4,2,2,70,70,300,1", "",
        "[Events]", "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"
    ]
    for seg in segments:
        a=max(seg["start"], start); b=min(seg["end"], end)
        if b <= a: continue
        txt=seg["text"].replace("{","(").replace("}",")").replace("\n"," ")
        lines.append(f"Dialogue: 0,{stamp(a-start)},{stamp(b-start)},Default,,0,0,0,,{txt}")
    out.write_text("\n".join(lines), encoding="utf-8")

@app.post("/api/clip")
async def create_clips(video: UploadFile = File(...), clip_count: int = Form(5), clip_length: int = Form(35)):
    if not video.filename.lower().endswith((".mp4", ".mov", ".mkv", ".webm", ".m4v")):
        raise HTTPException(400, "Please upload an MP4, MOV, MKV or WebM video.")
    job = uuid.uuid4().hex[:10]
    source = UPLOADS / f"{job}_{Path(video.filename).name}"
    with source.open("wb") as f:
        shutil.copyfileobj(video.file, f)
    try:
        probe = subprocess.check_output([
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", str(source)
        ], text=True).strip()
        duration = float(probe)
        transcript = transcribe(source)
        picks = pick_clips(transcript, duration, max(1, min(clip_count, 10)), max(15, min(clip_length, 60)))
        results=[]
        for idx, (start, end, score) in enumerate(picks, 1):
            ass = OUTPUTS / f"{job}_{idx}.ass"
            out = OUTPUTS / f"{job}_clip_{idx}.mp4"
            make_ass(transcript, start, end, ass)
            # Center-crop landscape/portrait video to a 9:16 frame, then burn subtitles.
            vf = f"scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,subtitles='{str(ass).replace(chr(92), '/')}'"
            run(["ffmpeg", "-y", "-ss", str(start), "-i", str(source), "-t", str(end-start),
                 "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
                 "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(out)])
            results.append({"name": f"Clip {idx}", "url": f"/outputs/{out.name}",
                            "start": round(start,1), "end": round(end,1)})
            ass.unlink(missing_ok=True)
        return {"job": job, "clips": results, "note": "Auto-selected using transcript heuristics. Review before publishing."}
    except Exception as e:
        raise HTTPException(500, f"Processing failed: {str(e)}")
    finally:
        source.unlink(missing_ok=True)

@app.post("/api/youtube")
def youtube_info(url: str = Form(...)):
    if not re.match(r"^https?://(www\\.)?(youtube\\.com|youtu\\.be)/", url.strip()):
        raise HTTPException(400, "Please enter a valid YouTube URL.")
    return {"message": "Direct downloading/processing from YouTube is not enabled. Upload a video you own or have permission to use. YouTube link import can be added with authorized YouTube API/OAuth access."}
